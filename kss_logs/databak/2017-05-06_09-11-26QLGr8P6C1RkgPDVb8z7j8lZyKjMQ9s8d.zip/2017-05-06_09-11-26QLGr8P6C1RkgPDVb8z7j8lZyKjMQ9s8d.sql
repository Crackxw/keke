-- KSS网络用户管理系统备份数据
-- 
-- 备份日期: 2017年 05月 06日 09:11
-- 主机: kg10.xyz
-- 数据库: kss_71BtKd2ZQryA
-- --------------------------------------------------------

SET NAMES 'utf8';

DROP TABLE IF EXISTS `kss_olddata`;
CREATE TABLE `kss_olddata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softcode` int(10) unsigned NOT NULL,
  `agentid` int(10) unsigned NOT NULL DEFAULT '0',
  `oldkey` varchar(24) NOT NULL,
  `newkey` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `viewtimes` int(11) NOT NULL,
  `ext1` varchar(32) NOT NULL DEFAULT '',
  `ext2` varchar(32) NOT NULL DEFAULT '',
  `ext3` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `oldkey` (`oldkey`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_tb_agentprice`;
CREATE TABLE `kss_tb_agentprice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL,
  `managerid` smallint(5) unsigned NOT NULL,
  `softid` smallint(5) unsigned NOT NULL,
  `keygroupid` int(11) NOT NULL DEFAULT '0',
  `keyprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tmpkey` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `softid` (`softid`),
  KEY `managerid` (`managerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_tb_badip`;
CREATE TABLE `kss_tb_badip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` int(10) unsigned DEFAULT NULL,
  `ip` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addtime` (`addtime`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_tb_config`;
CREATE TABLE `kss_tb_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kssversion` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sync_state` tinyint(3) unsigned NOT NULL,
  `sync_starttime` int(10) unsigned NOT NULL,
  `sync_endtime` int(10) unsigned NOT NULL,
  `sync_intro` varchar(200) NOT NULL,
  `clear_z_log` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `s_webtitle` varchar(100) NOT NULL DEFAULT '',
  `s_lang` varchar(20) NOT NULL DEFAULT 'GB2312',
  `s_bakmode` int(11) NOT NULL DEFAULT '0',
  `s_sendmailmode` int(11) NOT NULL DEFAULT '0',
  `s_sendmail` varchar(100) NOT NULL DEFAULT '****1@***.com',
  `s_sendmailpassword` varchar(100) NOT NULL DEFAULT '',
  `s_recvmail` varchar(100) NOT NULL DEFAULT '****2@***.com',
  `s_icp` varchar(100) NOT NULL DEFAULT '*ICP备******号',
  `s_webid` varchar(255) NOT NULL DEFAULT '',
  `s_rsamode` int(11) NOT NULL DEFAULT '0',
  `s_rsaekey` varchar(255) NOT NULL DEFAULT '',
  `s_rsankey` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kss_tb_config` (`id`,`kssversion`,`sync_state`,`sync_starttime`,`sync_endtime`,`sync_intro`,`clear_z_log`,`s_webtitle`,`s_lang`,`s_bakmode`,`s_sendmailmode`,`s_sendmail`,`s_sendmailpassword`,`s_recvmail`,`s_icp`,`s_webid`,`s_rsamode`,`s_rsaekey`,`s_rsankey`) VALUES 
('1','M09-P138','0','1353249564','0','','0','网络用户管理系统','GBK','0','0','****1@***.com','','****2@***.com','*ICP备******号','+==','0','','');
DROP TABLE IF EXISTS `kss_tb_keyset`;
CREATE TABLE `kss_tb_keyset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL,
  `softid` smallint(5) unsigned NOT NULL,
  `islock` tinyint(1) NOT NULL DEFAULT '0',
  `keyname` varchar(100) NOT NULL DEFAULT '未命名',
  `cday` decimal(6,2) NOT NULL,
  `points` int(10) unsigned NOT NULL DEFAULT '0',
  `linknum` int(10) unsigned NOT NULL DEFAULT '1',
  `extattr1` varchar(100) NOT NULL DEFAULT '',
  `prefix` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `retailprice` decimal(8,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`,`softid`,`islock`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kss_tb_keyset` (`id`,`pid`,`softid`,`islock`,`keyname`,`cday`,`points`,`linknum`,`extattr1`,`prefix`,`retailprice`) VALUES 
('1','10000','1','0','测试','31.00','0','1','','qqqq','30.00');
DROP TABLE IF EXISTS `kss_tb_lock`;
CREATE TABLE `kss_tb_lock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lockname` varchar(20) NOT NULL,
  `locktime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lockname` (`lockname`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
-- 表[kss_tb_lock]不需要同步数据 
DROP TABLE IF EXISTS `kss_tb_log_addcday`;
CREATE TABLE `kss_tb_log_addcday` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL,
  `managerid` int(10) unsigned NOT NULL,
  `softid` int(10) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `cday` decimal(8,2) NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '',
  `intro` varchar(250) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`,`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_tb_log_agentrmb`;
CREATE TABLE `kss_tb_log_agentrmb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL,
  `softid` int(10) unsigned NOT NULL DEFAULT '0',
  `managerid` smallint(5) unsigned NOT NULL,
  `opmanagerid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL,
  `oldrmb` decimal(10,2) NOT NULL DEFAULT '0.00',
  `changermb` decimal(10,2) NOT NULL,
  `optype` tinyint(2) unsigned NOT NULL,
  `ordernum` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `intro` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ordernum` (`ordernum`),
  KEY `managerid_o` (`managerid`,`optype`),
  KEY `managerid_a` (`managerid`,`addtime`),
  KEY `optype` (`optype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_tb_log_havereg`;
CREATE TABLE `kss_tb_log_havereg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softid` int(10) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `pccode` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pccode` (`pccode`(12))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_tb_log_login`;
CREATE TABLE `kss_tb_log_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `managerid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `loginip` bigint(20) unsigned NOT NULL DEFAULT '2130706433',
  `logintype` tinyint(1) NOT NULL,
  `logintime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `managerid` (`managerid`),
  KEY `logintime` (`logintime`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
INSERT INTO `kss_tb_log_login` (`id`,`pid`,`managerid`,`loginip`,`logintype`,`logintime`) VALUES 
('1','10000','1','2130706433','1','1493692047'),
('2','10000','1','2130706433','1','1493694682'),
('3','10000','1','2130706433','1','1493695691'),
('4','10000','1','2130706433','1','1493976548'),
('5','10000','1','2130706433','1','1493986001'),
('6','10000','1','2130706433','1','1494033078');
DROP TABLE IF EXISTS `kss_tb_log_pubuser`;
CREATE TABLE `kss_tb_log_pubuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softid` smallint(5) unsigned NOT NULL,
  `pccode` varchar(128) NOT NULL DEFAULT '',
  `nday` int(10) unsigned NOT NULL DEFAULT '0',
  `ntimes` smallint(5) unsigned NOT NULL,
  `lasttime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pccode` (`pccode`),
  KEY `nday` (`nday`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_tb_log_task`;
CREATE TABLE `kss_tb_log_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` int(10) unsigned NOT NULL,
  `intro` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
-- 表[kss_tb_log_task]不需要同步数据 
DROP TABLE IF EXISTS `kss_tb_log_ws`;
CREATE TABLE `kss_tb_log_ws` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `addtime` int(10) unsigned NOT NULL,
  `softcode` int(10) unsigned NOT NULL,
  `ivalue` tinyint(3) unsigned NOT NULL,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `softcode` (`softcode`,`ivalue`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
INSERT INTO `kss_tb_log_ws` (`id`,`addtime`,`softcode`,`ivalue`,`username`) VALUES 
('5','1493976191','1000001','56','qqqqP8879B'),
('6','1493976193','1000001','91','qqqqP8879B'),
('7','1493976625','1000001','81','qqqqP8879B'),
('8','1493977531','1000001','86','qqqqP8879B'),
('9','1493983752','1000001','94','qqqqP8879B');
DROP TABLE IF EXISTS `kss_tb_manager`;
CREATE TABLE `kss_tb_manager` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pmid` int(11) NOT NULL DEFAULT '0',
  `pid` smallint(5) unsigned NOT NULL,
  `isdel` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL,
  `maxusernum` int(11) unsigned NOT NULL,
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(40) NOT NULL,
  `passwordtime` int(10) unsigned NOT NULL DEFAULT '0',
  `linecode` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `islock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lockedinter` varchar(255) NOT NULL DEFAULT '',
  `addtime` datetime NOT NULL,
  `endtime` datetime NOT NULL,
  `lastlogintime` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `lastloginip` bigint(20) unsigned NOT NULL DEFAULT '2130706433',
  `qq` varchar(20) NOT NULL DEFAULT '10000',
  `tel` varchar(50) NOT NULL DEFAULT '13800138000',
  `email` varchar(50) NOT NULL DEFAULT '10000@qq.com',
  `jscript` text,
  `powerlist` varchar(255) NOT NULL DEFAULT '-',
  `alipayset` varchar(255) DEFAULT NULL,
  `tenpayset` varchar(255) DEFAULT NULL,
  `chinabankset` varchar(32) NOT NULL DEFAULT '',
  `alikey` varchar(50) NOT NULL DEFAULT '',
  `tenkey` varchar(50) NOT NULL DEFAULT '',
  `chinabankkey` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `e138set` varchar(200) NOT NULL DEFAULT '',
  `e138key` varchar(200) NOT NULL DEFAULT '',
  `payweb_title` varchar(100) DEFAULT '',
  `payweb_loginimg` varchar(255) DEFAULT '',
  `rmb` decimal(10,2) NOT NULL DEFAULT '0.00',
  `xfrmb` decimal(10,2) NOT NULL DEFAULT '0.00',
  `touzhirmb` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `pmid` (`pmid`),
  KEY `pid` (`pid`,`isdel`,`level`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kss_tb_manager` (`id`,`pmid`,`pid`,`isdel`,`level`,`maxusernum`,`username`,`password`,`passwordtime`,`linecode`,`islock`,`lockedinter`,`addtime`,`endtime`,`lastlogintime`,`lastloginip`,`qq`,`tel`,`email`,`jscript`,`powerlist`,`alipayset`,`tenpayset`,`chinabankset`,`alikey`,`tenkey`,`chinabankkey`,`e138set`,`e138key`,`payweb_title`,`payweb_loginimg`,`rmb`,`xfrmb`,`touzhirmb`) VALUES 
('1','0','10000','0','9','0','admin','21232f297a57a5a743894a0e4a801fc3','0','48L1kvdHir28MHa45W4w2ZZ83hdIvYPPgQ119FTd6m3dvz85','0','','2012-08-26 16:05:18','2088-12-31 23:00:00','2017-05-06 09:11:19','2130706433','10000','02712345678','10000@qq.com',NULL,'','create_partner_trade_by_buyer,2088002319190000,card@card.php','','','','','','','','在线售卡','','0.00','0.00','0.00');
DROP TABLE IF EXISTS `kss_tb_order`;
CREATE TABLE `kss_tb_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `softid` smallint(5) unsigned NOT NULL,
  `managerid` smallint(5) unsigned NOT NULL,
  `keygroupid` int(10) unsigned NOT NULL,
  `keycount` int(4) unsigned NOT NULL,
  `tags` varchar(50) NOT NULL,
  `ordernum` char(24) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `orderamount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `agentamount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `agentamount7` decimal(9,2) NOT NULL DEFAULT '0.00',
  `ordertype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `orderstatus` tinyint(1) unsigned NOT NULL DEFAULT '9',
  `beginid` int(11) NOT NULL DEFAULT '0',
  `ip` bigint(20) unsigned NOT NULL DEFAULT '2130706433',
  `addtime` int(10) unsigned NOT NULL,
  `payname` varchar(100) NOT NULL DEFAULT '',
  `payqq` varchar(12) NOT NULL DEFAULT '',
  `aliorderno` varchar(32) NOT NULL DEFAULT '',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `payqq` (`payqq`),
  KEY `ordernum` (`ordernum`(12)),
  KEY `sid_uid_ostatus` (`softid`,`managerid`,`orderstatus`,`addtime`),
  KEY `addtime` (`addtime`,`ordertype`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kss_tb_order` (`id`,`pid`,`softid`,`managerid`,`keygroupid`,`keycount`,`tags`,`ordernum`,`orderamount`,`agentamount`,`agentamount7`,`ordertype`,`orderstatus`,`beginid`,`ip`,`addtime`,`payname`,`payqq`,`aliorderno`,`paytype`) VALUES 
('1','10000','1','1','1','1','05-02','K705021029017879547691TN','0.00','0.00','0.00','1','9','1','2130706433','1493692141','','','','0');
DROP TABLE IF EXISTS `kss_tb_soft`;
CREATE TABLE `kss_tb_soft` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `autolock_time` smallint(6) NOT NULL DEFAULT '0',
  `autolock_times` smallint(6) NOT NULL DEFAULT '0',
  `autolock_time_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `autolock_ipnum` int(10) unsigned NOT NULL DEFAULT '0',
  `mac_blacklist` text,
  `pid` smallint(5) unsigned NOT NULL,
  `softcode` int(10) unsigned NOT NULL DEFAULT '0',
  `softmode` varchar(8) NOT NULL DEFAULT 'USOFT',
  `softmode2` varchar(10) NOT NULL DEFAULT '',
  `viewkey` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `softkey` varchar(40) NOT NULL DEFAULT 'nokey',
  `softname` varchar(40) NOT NULL DEFAULT '-',
  `softstatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dkbindpc` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `onetimeskeyattrid` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `returninfo1` varchar(250) NOT NULL DEFAULT '',
  `returninfo2` varchar(250) NOT NULL DEFAULT '',
  `softversion` int(10) unsigned NOT NULL DEFAULT '1',
  `softdownurl` varchar(255) NOT NULL DEFAULT 'http://',
  `ismustupdate` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `connectpenli` int(10) unsigned NOT NULL DEFAULT '15',
  `points_set` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `test_timearea` varchar(20) NOT NULL DEFAULT '0,23',
  `test_day` smallint(5) unsigned NOT NULL DEFAULT '1',
  `test_times` int(10) unsigned NOT NULL DEFAULT '1',
  `test_time` int(10) unsigned NOT NULL DEFAULT '15',
  `chkonline` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `outlinetime` smallint(5) unsigned NOT NULL DEFAULT '360',
  `outlinelock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `outlinetimes` int(10) unsigned NOT NULL DEFAULT '1',
  `outline_addtime` decimal(8,2) NOT NULL DEFAULT '0.00',
  `unbindpc_set` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `unbindpc_autotime` int(10) unsigned NOT NULL DEFAULT '15',
  `unbindpc_times` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `unbindpc_ctset` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `unbindpc_changetime` decimal(9,2) NOT NULL DEFAULT '1.00',
  `editbdinfo_changetime` decimal(9,2) NOT NULL DEFAULT '1.00',
  `czzs_keytypeid` char(4) NOT NULL DEFAULT '',
  `czzs_number` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `czzs_cday` decimal(9,2) NOT NULL DEFAULT '1.00',
  `czzs_points` int(10) unsigned NOT NULL DEFAULT '0',
  `nokeyreg` decimal(9,2) NOT NULL DEFAULT '0.00',
  `nokeyreg_points` int(10) unsigned NOT NULL DEFAULT '0',
  `tg_addtimetype` tinyint(1) NOT NULL DEFAULT '0',
  `tg_parentuseraddtime` tinyint(2) NOT NULL DEFAULT '0',
  `tg_newuseraddtime` tinyint(2) NOT NULL DEFAULT '0',
  `tg_points1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tg_points2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `advapi` text,
  `softintro` text,
  `softnotice` text,
  `updatelog` text,
  `mailtext` text,
  `clearlogday` tinyint(2) NOT NULL DEFAULT '0',
  `pccodestep` int(2) unsigned NOT NULL DEFAULT '1',
  `rsaenable` int(2) unsigned NOT NULL DEFAULT '0',
  `rsaekey` varchar(255) NOT NULL DEFAULT '',
  `rsankey` varchar(255) NOT NULL DEFAULT '',
  `freeregs` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `onlyonebdinfo` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `fregmanagerid` int(10) unsigned NOT NULL DEFAULT '0',
  `fregtag` varchar(100) NOT NULL DEFAULT '',
  `fregattr` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`,`softcode`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kss_tb_soft` (`id`,`autolock_time`,`autolock_times`,`autolock_time_ip`,`autolock_ipnum`,`mac_blacklist`,`pid`,`softcode`,`softmode`,`softmode2`,`viewkey`,`softkey`,`softname`,`softstatus`,`dkbindpc`,`onetimeskeyattrid`,`returninfo1`,`returninfo2`,`softversion`,`softdownurl`,`ismustupdate`,`connectpenli`,`points_set`,`test_timearea`,`test_day`,`test_times`,`test_time`,`chkonline`,`outlinetime`,`outlinelock`,`outlinetimes`,`outline_addtime`,`unbindpc_set`,`unbindpc_autotime`,`unbindpc_times`,`unbindpc_ctset`,`unbindpc_changetime`,`editbdinfo_changetime`,`czzs_keytypeid`,`czzs_number`,`czzs_cday`,`czzs_points`,`nokeyreg`,`nokeyreg_points`,`tg_addtimetype`,`tg_parentuseraddtime`,`tg_newuseraddtime`,`tg_points1`,`tg_points2`,`advapi`,`softintro`,`softnotice`,`updatelog`,`mailtext`,`clearlogday`,`pccodestep`,`rsaenable`,`rsaekey`,`rsankey`,`freeregs`,`onlyonebdinfo`,`fregmanagerid`,`fregtag`,`fregattr`) VALUES 
('1','0','0','0','0','','10000','1000001','KSOFT','0','0','ktYydMKockIefC4NnUAzcWYW','未命名软件xA8xl','0','1','','','','1','aHR0cDovLw==','0','15','0','0,23','1','1','15','0','120','2','1','0.00','1','15','1','0','0.00','0.00','','3','1.00','0','0.00','0','0','0','0','0','0','Ly/kuLrkuobmlrnkvr/mn6XnnIvvvIzor7flpI3liLbliLDorrDkuovmnKzkuK3mn6XnnIvmiJbkv67mlLkKCi8v5aaC5p6c6L2v5Lu25Z+65pys6K6+572u6YeM55qE6L+U5Zue5L+h5oGv5Li6QeS4uuepuu+8jOW5tuS4lOacrOWHveaVsOWtmOWcqO+8jOWuouaIt+err+WPluW+l+eahOi/lOWbnuS/oeaBr0HlsIbmmK/mraTlh73mlbDov5Tlm57nmoTlgLwKLy/imIXimIXimIXimIXimIXor6XmjqXlj6PkuLrns7vnu5/mjqXlj6PvvIzor7fkuI3opoHliKDpmaQKZnVuY3Rpb24gYWJfYSgpewoJcmV0dXJuICfov5Tlm57kv6Hmga/kuLpBJzsKfQoKLy/lpoLmnpzova/ku7bln7rmnKzorr7nva7ph4znmoTov5Tlm57kv6Hmga/kuLpC5Li656m677yM5bm25LiU5pys5Ye95pWw5a2Y5Zyo77yM5a6i5oi356uv5Y+W5b6X55qE6L+U5Zue5L+h5oGvQuWwhuaYr+atpOWHveaVsOi/lOWbnueahOWAvAovL+KYheKYheKYheKYheKYheivpeaOpeWPo+S4uuezu+e7n+aOpeWPo++8jOivt+S4jeimgeWIoOmZpApmdW5jdGlvbiBhYl9iKCl7CglyZXR1cm4gJ+i/lOWbnuS/oeaBr+S4ukInOwp9CgovL+aJo+eCueaOpeWPo2FkdmFwaSgidl9wb2ludHMs6KaB5omj55qE54K55pWwIikKLy/imIXimIXimIXimIXimIXor6XmjqXlj6PkuLrns7vnu5/mjqXlj6PvvIzor7fkuI3opoHliKDpmaQKZnVuY3Rpb24gdl9wb2ludHMoJHBvaW50cywkc3lzZ3VpZCl7CSAvL+esrOS4gOS4quWPguaVsOaYr+imgeaJo+eahOeCueaVsO+8jOesrOS6jOS4quWPguaVsOaYr+ezu+e7n+iHquWKqOmZhOWKoOeahOWPguaVsCAgCQoJJGVycmluZm89Jyc7CgkkcnQ9YXBpX3BvaW50cygkZXJyaW5mbywkcG9pbnRzLCRzeXNndWlkKTsKCWlmKCRydCE9PWZhbHNlKXsKCQkvL+aJo+eCueaIkOWKnwoJCXJldHVybiAkcnQ7Cgl9ZWxzZXsKCQkvL+aJo+eCueWksei0pe+8jOi/lOWbnuWksei0peS/oeaBrwoJCXJldHVybiAkZXJyaW5mbzsKCX0KfQoKLy/ov5nkuKrmmK/mnIDnroDljZXnmoRhZHZhcGnmjqXlj6PvvIzlj6rmnInmjqXlj6PlkI3ml6Dlj4LmlbAg44CQYWR2YXBpKCJ2X2dldGEiKeOAkQpmdW5jdGlvbiB2X2dldGEoKXsKCXJldHVybiAndl9nZXRh55qE6L+U5Zue5pWw5o2uJzsKfQoKLy/ov5nkuKrmmK/luKblj4LmlbDnmoTmjqXlj6PvvIwg5o6l5Y+j5ZCN5ZCO5pyJMuS4quWPguaVsCDjgJBhZHZhcGkoInZfZ2V0YiwxMDAsMjAwIikg56ys5LiA5Liq5piv5Ye95pWw5ZCN77yM5ZCO6L6555qE5Lik5Liq5omN5piv5Y+C5pWw44CRCmZ1bmN0aW9uIHZfZ2V0YigkdmFsMSwkdmFsMil7CglyZXR1cm4gJHZhbDErJHZhbDI7ICAgLy/lr7nkvKDpgJLov4fmnaXnmoTlj4LmlbDov5vooYznroDljZXnmoTliqDms5Xov5DnrpcKfQoKLy/kuIvovrnkvaDlj6/ku6Xoh6rnlLHmt7vliqDoh6rlt7HnmoTmjqXlj6PlrprkuYkKCgo=','','MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMQ==','','','0','1','0','','','0','1','0','','');
DROP TABLE IF EXISTS `kss_tb_sql`;
CREATE TABLE `kss_tb_sql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `sqltext` text NOT NULL,
  `isact` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `notifyid` char(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `addtime` (`addtime`),
  KEY `notifyid` (`notifyid`(8),`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
-- 表[kss_tb_sql]不需要同步数据 
DROP TABLE IF EXISTS `kss_tb_sql_active`;
CREATE TABLE `kss_tb_sql_active` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tbname` varchar(11) NOT NULL,
  `username` varchar(21) NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `pccode` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `notifyid` char(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `notifyid` (`notifyid`(8))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
-- 表[kss_tb_sql_active]不需要同步数据 
DROP TABLE IF EXISTS `kss_tb_sql_points`;
CREATE TABLE `kss_tb_sql_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `tbname` varchar(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `points` int(10) unsigned NOT NULL DEFAULT '0',
  `guid` char(24) NOT NULL,
  `svrid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `notifyid` char(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `guid` (`guid`(10)),
  KEY `notifyid` (`notifyid`(8))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
-- 表[kss_tb_sql_points]不需要同步数据 
DROP TABLE IF EXISTS `kss_z_cz_10000_1`;
CREATE TABLE `kss_z_cz_10000_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `addtime` int(10) unsigned NOT NULL,
  `cztype` tinyint(2) unsigned NOT NULL,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `oldcday` decimal(9,2) unsigned NOT NULL,
  `newcday` decimal(9,2) unsigned NOT NULL,
  `oldtimes` int(10) unsigned NOT NULL,
  `newtimes` int(10) unsigned NOT NULL,
  `keys` varchar(170) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `tzxguser` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `addtime` (`addtime`),
  KEY `username` (`username`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='客户帐号时间变更日志';
DROP TABLE IF EXISTS `kss_z_key_10000_1`;
CREATE TABLE `kss_z_key_10000_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `managerid` smallint(5) unsigned NOT NULL,
  `keyfix` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `keys` char(6) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `keyspassword` char(22) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `ordernum` char(24) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cday` decimal(8,2) NOT NULL,
  `linknum` int(4) unsigned NOT NULL DEFAULT '1',
  `points` int(8) unsigned NOT NULL DEFAULT '0',
  `keyextattr` varchar(100) NOT NULL DEFAULT '',
  `tag` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `islock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isback` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cztime` int(10) unsigned NOT NULL DEFAULT '0',
  `czusername` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `keys` (`keys`),
  KEY `ordernum` (`ordernum`(10)),
  KEY `keyextattr` (`keyextattr`(10)),
  KEY `tag` (`tag`(10)),
  KEY `czusername` (`czusername`(10)),
  KEY `islock` (`islock`),
  KEY `isback` (`isback`),
  KEY `keyfix_uid_cztime` (`keyfix`,`managerid`,`cztime`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kss_z_key_10000_1` (`id`,`managerid`,`keyfix`,`keys`,`keyspassword`,`addtime`,`ordernum`,`cday`,`linknum`,`points`,`keyextattr`,`tag`,`islock`,`isback`,`cztime`,`czusername`) VALUES 
('1','1','qqqq','P8879B','U9ISa58LXr9i654t78K8N3','1493692141','K705021029017879547691TN','31.00','1','0','','05-02','0','0','1493692299','qqqqP8879B');
DROP TABLE IF EXISTS `kss_z_key_10000_1_recycle`;
CREATE TABLE `kss_z_key_10000_1_recycle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `managerid` smallint(5) unsigned NOT NULL,
  `keyfix` char(4) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `keys` char(6) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `keyspassword` char(22) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `ordernum` char(24) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cday` decimal(8,2) NOT NULL,
  `linknum` int(4) unsigned NOT NULL DEFAULT '1',
  `points` int(8) unsigned NOT NULL DEFAULT '0',
  `keyextattr` varchar(100) NOT NULL DEFAULT '',
  `tag` varchar(50) NOT NULL DEFAULT '',
  `islock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isback` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cztime` int(10) unsigned NOT NULL DEFAULT '0',
  `czusername` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `deltime` int(10) unsigned NOT NULL,
  `delmid` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keys` (`keys`),
  KEY `ordernum` (`ordernum`(10)),
  KEY `keyextattr` (`keyextattr`(10)),
  KEY `tag` (`tag`(10)),
  KEY `czusername` (`czusername`(10)),
  KEY `islock` (`islock`),
  KEY `isback` (`isback`),
  KEY `deltime` (`deltime`),
  KEY `keyfix_uid_cztime` (`keyfix`,`managerid`,`cztime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `kss_z_log_10000_1`;
CREATE TABLE `kss_z_log_10000_1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `optype` tinyint(2) unsigned NOT NULL,
  `clientid` smallint(5) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `ip` bigint(20) unsigned NOT NULL,
  `pccode` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `linecode` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `opccode` varchar(128) CHARACTER SET utf8 NOT NULL,
  `oip` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `addtime` (`addtime`),
  KEY `keys` (`username`(10),`optype`,`clientid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=ascii;
-- 表[kss_z_log_10000_1]不需要同步数据 
DROP TABLE IF EXISTS `kss_z_user_10000_1`;
CREATE TABLE `kss_z_user_10000_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `istempuser` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `managerid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password2` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cday` decimal(8,2) NOT NULL,
  `linknum` int(4) unsigned NOT NULL DEFAULT '1',
  `points` int(8) NOT NULL DEFAULT '0',
  `keyextattr` varchar(100) NOT NULL DEFAULT '',
  `islock` int(1) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '-',
  `bdinfo` varchar(100) NOT NULL DEFAULT '',
  `linecode` varchar(10) NOT NULL DEFAULT '',
  `pccode` varchar(128) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  `isonline` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastip` bigint(20) unsigned NOT NULL DEFAULT '0',
  `activetimes` int(10) unsigned NOT NULL DEFAULT '0',
  `unlocktimes` int(10) unsigned NOT NULL DEFAULT '0',
  `unlockday` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `cztimes` int(10) unsigned NOT NULL DEFAULT '0',
  `isusetestkey` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `parentuser` varchar(100) NOT NULL DEFAULT '',
  `intro` varchar(50) NOT NULL DEFAULT '',
  `updata` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(10)),
  KEY `managerid` (`managerid`),
  KEY `tag` (`tag`),
  KEY `keyextattr` (`keyextattr`),
  KEY `lasttime` (`lasttime`,`isonline`),
  KEY `islock` (`islock`),
  KEY `endtime` (`endtime`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kss_z_user_10000_1` (`id`,`istempuser`,`managerid`,`username`,`password`,`password2`,`cday`,`linknum`,`points`,`keyextattr`,`islock`,`tag`,`bdinfo`,`linecode`,`pccode`,`addtime`,`starttime`,`endtime`,`lasttime`,`isonline`,`lastip`,`activetimes`,`unlocktimes`,`unlockday`,`cztimes`,`isusetestkey`,`parentuser`,`intro`,`updata`) VALUES 
('1','0','1','qqqqP8879B','U9ISa58LXr','9i654t78K8N3','31.00','1','0','0','0','05-02','','2643423918','080027EB44A6','1493692299','1493692299','1496370699','1493983761','0','2130706433','9','0','0','1','0','','','');
DROP TABLE IF EXISTS `kss_z_user_10000_1_recycle`;
CREATE TABLE `kss_z_user_10000_1_recycle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `istempuser` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `managerid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password2` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cday` decimal(8,2) NOT NULL,
  `linknum` int(4) unsigned NOT NULL DEFAULT '1',
  `points` int(8) NOT NULL DEFAULT '0',
  `keyextattr` varchar(100) NOT NULL DEFAULT '',
  `islock` int(1) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '-',
  `bdinfo` varchar(100) NOT NULL DEFAULT '',
  `linecode` varchar(10) NOT NULL DEFAULT '',
  `pccode` varchar(128) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  `isonline` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastip` bigint(20) unsigned NOT NULL DEFAULT '0',
  `activetimes` int(10) unsigned NOT NULL DEFAULT '0',
  `unlocktimes` int(10) unsigned NOT NULL DEFAULT '0',
  `unlockday` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `cztimes` int(10) unsigned NOT NULL DEFAULT '0',
  `isusetestkey` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `parentuser` varchar(100) NOT NULL DEFAULT '',
  `intro` varchar(50) NOT NULL DEFAULT '',
  `updata` varchar(128) NOT NULL DEFAULT '',
  `delmid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `deltime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(10)),
  KEY `managerid` (`managerid`),
  KEY `tag` (`tag`),
  KEY `keyextattr` (`keyextattr`),
  KEY `lasttime` (`lasttime`,`isonline`),
  KEY `islock` (`islock`),
  KEY `endtime` (`endtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
